export { default } from "./IntelligencePage";

import React, { useCallback, useEffect, useState } from "react";
import {
  Upload,
  FileText,
  CheckCircle,
  AlertCircle,
  Loader2,
  RefreshCw,
  Save,
  X,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import DashboardLayout from "../components/DashboardLayout";
import api from "../api";

const MAX_MB = 5;

function TagEditor({ tags, onChange, placeholder, colorClass }) {
  const [input, setInput] = useState("");

  function addTag(e) {
    if ((e.key === "Enter" || e.key === ",") && input.trim()) {
      e.preventDefault();
      const tag = input.trim().replace(/,$/, "");
      if (tag && !tags.includes(tag)) onChange([...tags, tag]);
      setInput("");
    }
  }

  return (
    <div className="bg-navy-700/50 border border-white/10 rounded-xl px-3 py-2 flex flex-wrap gap-2 focus-within:border-cyan-500 transition min-h-[46px]">
      {tags.map((t) => (
        <span key={t} className={`flex items-center gap-1 ${colorClass} text-xs px-2.5 py-1 rounded-full border`}>
          {t}
          <button type="button" onClick={() => onChange(tags.filter((x) => x !== t))}>
            <X className="w-3 h-3" />
          </button>
        </span>
      ))}
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={addTag}
        placeholder={tags.length === 0 ? placeholder : "Add more…"}
        className="flex-1 bg-transparent text-sm text-white placeholder-slate-500 focus:outline-none min-w-[120px]"
      />
    </div>
  );
}

function Section({ title, children, defaultOpen = true }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border border-white/5 rounded-xl overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen((p) => !p)}
        className="w-full flex items-center justify-between px-5 py-4 bg-navy-700/40 text-left"
      >
        <span className="text-sm font-semibold text-white">{title}</span>
        {open ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
      </button>
      {open && <div className="px-5 py-4 bg-navy-800/40">{children}</div>}
    </div>
  );
}

export default function ResumeUploadPage() {
  const [dragging, setDragging] = useState(false);
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const [parsed, setParsed] = useState(null); // { resume_id, filename, parsed_information }
  const [existing, setExisting] = useState(null);

  // Editable extracted state
  const [techSkills, setTechSkills] = useState([]);
  const [softSkills, setSoftSkills] = useState([]);
  const [jobRoles, setJobRoles] = useState([]);
  const [experience, setExperience] = useState([]);
  const [education, setEducation] = useState([]);

  const [applying, setApplying] = useState(false);
  const [applySuccess, setApplySuccess] = useState("");
  const [applyError, setApplyError] = useState("");

  // Load existing latest resume on mount
  useEffect(() => {
    api.get("/api/resume/latest").then((r) => setExisting(r.data)).catch(() => {});
  }, []);

  function populateEditable(info) {
    setTechSkills(info?.technical_skills || []);
    setSoftSkills([]);
    setJobRoles(info?.job_roles || []);
    setExperience(info?.experience || []);
    setEducation(info?.education || []);
  }

  function validateFile(f) {
    if (!f) return "No file selected.";
    const ext = f.name.split(".").pop().toLowerCase();
    if (!["pdf", "docx"].includes(ext))
      return `Unsupported format ".${ext}". Please upload PDF or DOCX.`;
    if (f.size > MAX_MB * 1024 * 1024)
      return `File size ${(f.size / 1024 / 1024).toFixed(1)} MB exceeds the ${MAX_MB} MB limit.`;
    return null;
  }

  function handleFiles(files) {
    const f = files[0];
    const err = validateFile(f);
    if (err) { setUploadError(err); return; }
    setUploadError("");
    setFile(f);
    setParsed(null);
  }

  const onDrop = useCallback((e) => {
    e.preventDefault();
    setDragging(false);
    handleFiles(e.dataTransfer.files);
  }, []);

  async function handleUpload() {
    if (!file) return;
    setUploading(true);
    setUploadError("");
    setParsed(null);
    setApplySuccess("");
    setApplyError("");
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await api.post("/api/resume/upload", fd, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setParsed(res.data);
      populateEditable(res.data.parsed_information);
      setExisting(res.data);
    } catch (err) {
      setUploadError(
        err.response?.data?.detail || "Upload failed. Please try again."
      );
    } finally {
      setUploading(false);
    }
  }

  async function handleApply() {
    if (!parsed) return;
    setApplying(true);
    setApplyError("");
    setApplySuccess("");
    try {
      await api.post(`/api/resume/${parsed.resume_id}/apply`, {
        technical_skills: techSkills,
        soft_skills: softSkills,
        job_roles: jobRoles,
        experience: experience,
        education: education,
      });
      setApplySuccess("Extracted data saved to your profile!");
      setTimeout(() => setApplySuccess(""), 4000);
    } catch (err) {
      setApplyError(err.response?.data?.detail || "Failed to save data.");
    } finally {
      setApplying(false);
    }
  }

  return (
    <DashboardLayout title="Resume Upload">
      <div className="max-w-3xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h2 className="text-2xl font-bold text-white">Resume Upload &amp; Parsing</h2>
          <p className="text-slate-400 text-sm mt-1">
            Upload your resume and let CareerCast extract key information automatically.
          </p>
        </div>

        {/* Existing resume notice */}
        {existing && !parsed && (
          <div className="flex items-center gap-3 bg-navy-800 border border-cyan-500/20 rounded-xl px-5 py-4 text-sm">
            <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0" />
            <div>
              <p className="text-white font-medium">Previously uploaded: {existing.filename}</p>
              <p className="text-slate-400 text-xs mt-0.5">
                Uploaded {new Date(existing.upload_date).toLocaleDateString()}
              </p>
            </div>
            <button
              onClick={() => { setParsed(existing); populateEditable(existing.parsed_information); }}
              className="ml-auto text-cyan-400 hover:text-cyan-300 text-xs font-medium flex items-center gap-1"
            >
              <RefreshCw className="w-3.5 h-3.5" /> View Parsed
            </button>
          </div>
        )}

        {/* Drop zone */}
        <div
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
          className={`border-2 border-dashed rounded-2xl p-10 text-center transition cursor-pointer ${
            dragging
              ? "border-cyan-400 bg-cyan-500/5"
              : "border-white/10 hover:border-white/20 bg-navy-800/40"
          }`}
          onClick={() => document.getElementById("resume-file-input").click()}
        >
          <input
            id="resume-file-input"
            type="file"
            accept=".pdf,.docx"
            className="hidden"
            onChange={(e) => handleFiles(e.target.files)}
          />
          <Upload className={`w-10 h-10 mx-auto mb-3 ${dragging ? "text-cyan-400" : "text-slate-500"}`} />
          {file ? (
            <div>
              <p className="text-white font-medium">{file.name}</p>
              <p className="text-slate-400 text-xs mt-1">{(file.size / 1024).toFixed(1)} KB — ready to upload</p>
            </div>
          ) : (
            <div>
              <p className="text-white font-medium">Drag &amp; drop your resume here</p>
              <p className="text-slate-400 text-sm mt-1">or click to browse</p>
              <p className="text-slate-500 text-xs mt-3">Supported: PDF, DOCX · Max {MAX_MB} MB</p>
            </div>
          )}
        </div>

        {uploadError && (
          <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-3 text-sm text-red-400">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            {uploadError}
          </div>
        )}

        {file && !parsed && (
          <button
            onClick={handleUpload}
            disabled={uploading}
            className="flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-60 text-white font-semibold px-6 py-3 rounded-xl transition shadow-lg shadow-cyan-500/20"
          >
            {uploading ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> Uploading &amp; Parsing…</>
            ) : (
              <><Upload className="w-4 h-4" /> Upload &amp; Parse Resume</>
            )}
          </button>
        )}

        {/* Parsed results */}
        {parsed && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <h3 className="text-base font-semibold text-white">
                  Extracted Information
                </h3>
              </div>
              <p className="text-slate-400 text-xs">Review and correct below, then save to profile</p>
            </div>

            <Section title="Technical Skills">
              <TagEditor
                tags={techSkills}
                onChange={setTechSkills}
                placeholder="Add skills…"
                colorClass="bg-cyan-500/15 text-cyan-400 border-cyan-500/25"
              />
            </Section>

            <Section title="Education Details">
              <div className="space-y-2">
                {education.length > 0 ? (
                  education.map((line, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <p className="text-slate-300 text-sm flex-1 leading-relaxed">{line}</p>
                      <button onClick={() => setEducation(education.filter((_, j) => j !== i))}>
                        <X className="w-3.5 h-3.5 text-slate-500 hover:text-red-400 mt-0.5" />
                      </button>
                    </div>
                  ))
                ) : (
                  <p className="text-slate-500 text-sm">No education information extracted.</p>
                )}
              </div>
            </Section>

            <Section title="Job Roles Detected">
              <TagEditor
                tags={jobRoles}
                onChange={setJobRoles}
                placeholder="Add roles…"
                colorClass="bg-blue-500/15 text-blue-400 border-blue-500/25"
              />
            </Section>

            <Section title="Experience Information">
              <div className="space-y-2">
                {experience.length > 0 ? (
                  experience.map((line, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <p className="text-slate-300 text-sm flex-1 leading-relaxed">{line}</p>
                      <button onClick={() => setExperience(experience.filter((_, j) => j !== i))}>
                        <X className="w-3.5 h-3.5 text-slate-500 hover:text-red-400 mt-0.5" />
                      </button>
                    </div>
                  ))
                ) : (
                  <p className="text-slate-500 text-sm">No experience information extracted.</p>
                )}
              </div>
            </Section>

            <Section title="Soft Skills (Manual Entry)" defaultOpen={false}>
              <TagEditor
                tags={softSkills}
                onChange={setSoftSkills}
                placeholder="Add soft skills…"
                colorClass="bg-purple-500/15 text-purple-400 border-purple-500/25"
              />
            </Section>

            {applySuccess && (
              <div className="flex items-center gap-2 bg-green-500/10 border border-green-500/20 rounded-xl px-4 py-3 text-sm text-green-400">
                <CheckCircle className="w-4 h-4" /> {applySuccess}
              </div>
            )}
            {applyError && (
              <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-3 text-sm text-red-400">
                <AlertCircle className="w-4 h-4" /> {applyError}
              </div>
            )}

            <div className="flex items-center gap-3">
              <button
                onClick={handleApply}
                disabled={applying}
                className="flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-60 text-white font-semibold px-6 py-3 rounded-xl transition shadow-lg shadow-cyan-500/20"
              >
                {applying ? (
                  <><Loader2 className="w-4 h-4 animate-spin" /> Saving…</>
                ) : (
                  <><Save className="w-4 h-4" /> Save to Profile</>
                )}
              </button>
              <button
                onClick={() => { setFile(null); setParsed(null); setUploadError(""); }}
                className="px-6 py-3 rounded-xl border border-white/10 text-slate-300 hover:text-white hover:border-white/20 transition text-sm font-medium"
              >
                Upload Different File
              </button>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}

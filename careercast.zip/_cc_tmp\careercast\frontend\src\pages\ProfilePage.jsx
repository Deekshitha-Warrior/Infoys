import React, { useEffect, useState } from "react";
import { CheckCircle, AlertCircle, Loader2, X, Edit3, Save } from "lucide-react";
import DashboardLayout from "../components/DashboardLayout";
import api from "../api";

/* ── Tag input ─────────────────────────────────────────────────────────── */
function TagInput({ value = [], onChange, placeholder, colorScheme = "blue" }) {
  const [input, setInput] = useState("");

  const scheme = {
    blue: {
      pill: "bg-surface-hover text-brand-blue border border-brand-blue/30",
      ring: "focus:border-brand-blue focus:ring-2 focus:ring-brand-blue/15",
    },
    teal: {
      pill: "bg-surface-teal text-brand-teal border border-brand-teal/30",
      ring: "focus:border-brand-teal focus:ring-2 focus:ring-brand-teal/15",
    },
  }[colorScheme];

  function addTag(e) {
    if ((e.key === "Enter" || e.key === ",") && input.trim()) {
      e.preventDefault();
      const tag = input.trim().replace(/,$/, "");
      if (tag && !value.includes(tag)) onChange([...value, tag]);
      setInput("");
    }
  }

  return (
    <div className={`bg-white border border-ink-border rounded-xl px-3 py-2 flex flex-wrap gap-2 ${scheme.ring} transition-all min-h-[46px]`}>
      {value.map((tag) => (
        <span key={tag} className={`flex items-center gap-1 ${scheme.pill} text-xs px-2.5 py-1 rounded-full font-medium`}>
          {tag}
          <button type="button" onClick={() => onChange(value.filter((t) => t !== tag))} className="hover:opacity-60 transition-opacity">
            <X style={{ width: "11px", height: "11px" }} />
          </button>
        </span>
      ))}
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={addTag}
        placeholder={value.length === 0 ? placeholder : "Add more…"}
        className="flex-1 bg-transparent text-sm text-ink-primary placeholder-ink-secondary/50 focus:outline-none min-w-[120px] py-0.5"
      />
    </div>
  );
}

/* ── Read-only tag display ─────────────────────────────────────────────── */
function TagDisplay({ tags, colorScheme = "blue", empty = "None added" }) {
  const pillClass = colorScheme === "blue"
    ? "bg-surface-hover text-brand-blue border border-brand-blue/20"
    : "bg-surface-teal text-brand-teal border border-brand-teal/20";
  return (
    <div className="flex flex-wrap gap-2">
      {(tags || []).length > 0
        ? tags.map((s) => (
            <span key={s} className={`${pillClass} text-xs px-3 py-1 rounded-full font-medium`}>{s}</span>
          ))
        : <span className="text-ink-secondary/60 text-sm italic">{empty}</span>
      }
    </div>
  );
}

/* ── Field wrapper ─────────────────────────────────────────────────────── */
function Field({ label, children }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-ink-secondary uppercase tracking-wider mb-2">{label}</label>
      {children}
    </div>
  );
}

const inputCls = [
  "w-full bg-white border border-ink-border rounded-xl px-4 py-2.5 text-ink-primary text-sm",
  "placeholder-ink-secondary/50 outline-none transition-all duration-150",
  "focus:border-brand-blue focus:ring-2 focus:ring-brand-blue/15 hover:border-brand-blue/40",
  "disabled:bg-surface-bg disabled:text-ink-secondary disabled:cursor-not-allowed",
].join(" ");
const selectCls = inputCls + " appearance-none cursor-pointer";

const QUALIFICATIONS    = ["High School", "Diploma", "Bachelor's", "Master's", "PhD", "Other"];
const EXPERIENCE_OPTIONS = [
  "Fresher (0 years)", "Less than 1 year", "1-2 years", "2-3 years",
  "3-5 years", "5-7 years", "7-10 years", "10+ years",
];

/* ── Section card ──────────────────────────────────────────────────────── */
function SectionCard({ step, label, stepColor, topLineColor, children, delay = 0 }) {
  return (
    <section
      className="card rounded-2xl overflow-hidden animate-slide-up"
      style={{ animationDelay: `${delay}ms`, animationFillMode: "both" }}
    >
      {/* Top accent line */}
      <div className={`h-0.5 ${topLineColor}`} />
      <div className="px-6 py-5">
        <h3 className="text-base font-semibold text-ink-primary flex items-center gap-3 mb-5">
          <span className={`w-7 h-7 rounded-lg ${stepColor} flex items-center justify-center text-xs font-bold text-white shadow-sm flex-shrink-0`}>
            {step}
          </span>
          {label}
        </h3>
        {children}
      </div>
    </section>
  );
}

export default function ProfilePage() {
  const [form, setForm] = useState({
    qualification: "", degree: "", specialization: "", institution: "",
    graduation_year: "", technical_skills: [], soft_skills: [],
    work_experience: "", previous_role: "", certifications: "",
  });
  const [editing,    setEditing]    = useState(false);
  const [hasProfile, setHasProfile] = useState(false);
  const [loading,    setLoading]    = useState(true);
  const [saving,     setSaving]     = useState(false);
  const [success,    setSuccess]    = useState("");
  const [error,      setError]      = useState("");

  useEffect(() => {
    api.get("/api/profile/me").then((res) => {
      const p = res.data;
      setForm({
        qualification:    p.qualification   || "",
        degree:           p.degree          || "",
        specialization:   p.specialization  || "",
        institution:      p.institution     || "",
        graduation_year:  p.graduation_year || "",
        technical_skills: p.technical_skills || [],
        soft_skills:      p.soft_skills     || [],
        work_experience:  p.work_experience || "",
        previous_role:    p.previous_role   || "",
        certifications:   p.certifications  || "",
      });
      setHasProfile(!!p.profile_id);
      setEditing(!p.profile_id);
    }).catch(() => {
      setEditing(true);
    }).finally(() => setLoading(false));
  }, []);

  function handleChange(e) {
    setForm((p) => ({ ...p, [e.target.name]: e.target.value }));
  }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setSuccess("");
    setError("");
    try {
      await api.post("/api/profile/me", form);
      setHasProfile(true);
      setEditing(false);
      setSuccess("Profile saved successfully!");
      setTimeout(() => setSuccess(""), 4000);
    } catch (err) {
      setError(err.response?.data?.detail || "Failed to save profile. Please try again.");
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <DashboardLayout title="My Profile">
        <div className="flex flex-col items-center justify-center h-64 gap-4">
          <Loader2 style={{ width: "28px", height: "28px", color: "#2563EB" }} className="animate-spin" />
          <p className="text-ink-secondary text-sm">Loading your profile…</p>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title="My Profile">
      <div className="max-w-3xl mx-auto">

        {/* Header */}
        <div className="flex items-start justify-between mb-6 animate-slide-up" style={{ animationFillMode: "both" }}>
          <div>
            <h2 className="text-2xl font-bold text-ink-primary">Profile Information</h2>
            <p className="text-ink-secondary text-sm mt-1">Keep your details current for accurate career insights.</p>
          </div>
          {hasProfile && !editing && (
            <button
              onClick={() => setEditing(true)}
              className="flex items-center gap-2 bg-surface-hover hover:bg-brand-blue/10 border border-brand-blue/25 text-brand-blue text-sm font-semibold px-4 py-2 rounded-xl transition-all group"
            >
              <Edit3 style={{ width: "14px", height: "14px" }} className="group-hover:rotate-12 transition-transform" />
              Edit Profile
            </button>
          )}
        </div>

        {/* Alerts */}
        {success && (
          <div className="flex items-center gap-3 bg-green-50 border border-green-200 rounded-xl px-4 py-3 mb-5 animate-fade-in">
            <CheckCircle style={{ width: "18px", height: "18px", color: "#16A34A", flexShrink: 0 }} />
            <p className="text-green-800 text-sm font-medium">{success}</p>
          </div>
        )}
        {error && (
          <div className="flex items-center gap-3 bg-red-50 border border-red-200 rounded-xl px-4 py-3 mb-5 animate-fade-in">
            <AlertCircle style={{ width: "18px", height: "18px", color: "#DC2626", flexShrink: 0 }} />
            <p className="text-red-700 text-sm">{error}</p>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-5">

          {/* ── 1. Education ─────────────────────────────────── */}
          <SectionCard step="1" label="Education" stepColor="bg-brand-blue" topLineColor="bg-gradient-to-r from-brand-blue/0 via-brand-blue/50 to-brand-blue/0" delay={0}>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Highest Qualification">
                <select name="qualification" value={form.qualification} onChange={handleChange} disabled={!editing} className={selectCls}>
                  <option value="">Select qualification</option>
                  {QUALIFICATIONS.map((q) => <option key={q}>{q}</option>)}
                </select>
              </Field>
              <Field label="Degree / Program">
                <input name="degree" value={form.degree} onChange={handleChange} disabled={!editing} placeholder="e.g. B.Tech Computer Science" className={inputCls} />
              </Field>
              <Field label="Specialization">
                <input name="specialization" value={form.specialization} onChange={handleChange} disabled={!editing} placeholder="e.g. Artificial Intelligence" className={inputCls} />
              </Field>
              <Field label="College / Institution">
                <input name="institution" value={form.institution} onChange={handleChange} disabled={!editing} placeholder="e.g. IIT Bombay" className={inputCls} />
              </Field>
              <Field label="Graduation Year">
                <input type="number" name="graduation_year" value={form.graduation_year} onChange={handleChange} disabled={!editing} placeholder="e.g. 2025" min="1990" max="2035" className={inputCls} />
              </Field>
            </div>
          </SectionCard>

          {/* ── 2. Skills ────────────────────────────────────── */}
          <SectionCard step="2" label="Skills" stepColor="bg-brand-teal" topLineColor="bg-gradient-to-r from-brand-teal/0 via-brand-teal/50 to-brand-teal/0" delay={80}>
            <div className="space-y-5">
              <Field label="Technical Skills">
                {editing ? (
                  <>
                    <p className="text-ink-secondary/70 text-xs mb-2">Type a skill and press Enter or comma to add it as a tag</p>
                    <TagInput value={form.technical_skills} onChange={(v) => setForm((p) => ({ ...p, technical_skills: v }))} placeholder="e.g. Python, React, SQL…" colorScheme="blue" />
                  </>
                ) : (
                  <TagDisplay tags={form.technical_skills} colorScheme="blue" empty="No technical skills added yet" />
                )}
              </Field>
              <Field label="Soft Skills">
                {editing ? (
                  <>
                    <p className="text-ink-secondary/70 text-xs mb-2">Type a skill and press Enter or comma to add it as a tag</p>
                    <TagInput value={form.soft_skills} onChange={(v) => setForm((p) => ({ ...p, soft_skills: v }))} placeholder="e.g. Communication, Leadership…" colorScheme="teal" />
                  </>
                ) : (
                  <TagDisplay tags={form.soft_skills} colorScheme="teal" empty="No soft skills added yet" />
                )}
              </Field>
            </div>
          </SectionCard>

          {/* ── 3. Professional ──────────────────────────────── */}
          <SectionCard step="3" label="Professional Information" stepColor="bg-gradient-to-br from-brand-blue to-brand-teal" topLineColor="bg-gradient-to-r from-brand-blue/0 via-brand-teal/50 to-brand-blue/0" delay={160}>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Work Experience">
                <select name="work_experience" value={form.work_experience} onChange={handleChange} disabled={!editing} className={selectCls}>
                  <option value="">Select experience level</option>
                  {EXPERIENCE_OPTIONS.map((o) => <option key={o}>{o}</option>)}
                </select>
              </Field>
              <Field label="Previous Job Role">
                <input name="previous_role" value={form.previous_role} onChange={handleChange} disabled={!editing} placeholder="e.g. Software Engineer Intern" className={inputCls} />
              </Field>
              <Field label="Certifications">
                <input name="certifications" value={form.certifications} onChange={handleChange} disabled={!editing} placeholder="e.g. AWS Certified, Google Data Analytics" className={`${inputCls} sm:col-span-2`} />
              </Field>
            </div>
          </SectionCard>

          {/* ── Save / Cancel ─────────────────────────────────── */}
          {editing && (
            <div className="flex items-center gap-3 animate-slide-up" style={{ animationDelay: "200ms", animationFillMode: "both" }}>
              <button
                type="submit"
                disabled={saving}
                className="flex items-center gap-2 bg-brand-blue hover:bg-brand-blue-dark disabled:opacity-60 text-white font-semibold px-7 py-2.5 rounded-xl transition-all shadow-sm hover:shadow-md"
              >
                {saving
                  ? <Loader2 style={{ width: "15px", height: "15px" }} className="animate-spin" />
                  : <Save style={{ width: "15px", height: "15px" }} />
                }
                {saving ? "Saving…" : "Save Profile"}
              </button>
              {hasProfile && (
                <button
                  type="button"
                  onClick={() => setEditing(false)}
                  className="px-6 py-2.5 rounded-xl border border-ink-border text-ink-secondary hover:text-ink-primary hover:border-brand-blue/30 hover:bg-surface-hover transition-all text-sm font-medium"
                >
                  Cancel
                </button>
              )}
            </div>
          )}
        </form>
      </div>
    </DashboardLayout>
  );
}

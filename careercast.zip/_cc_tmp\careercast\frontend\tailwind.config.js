/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        // ── Core brand ────────────────────────────────────────────────────
        purple: {
          50:  "rgb(250 245 255 / <alpha-value>)",  // #FAF5FF
          100: "rgb(243 232 255 / <alpha-value>)",  // #F3E8FF  light purple bg
          200: "rgb(233 213 255 / <alpha-value>)",  // #E9D5FF
          300: "rgb(216 180 254 / <alpha-value>)",  // #D8B4FE
          400: "rgb(192 132 252 / <alpha-value>)",  // #C084FC
          500: "rgb(168 85 247 / <alpha-value>)",   // #A855F7  secondary accent
          600: "rgb(139 92 246 / <alpha-value>)",   // #8B5CF6  PRIMARY accent
          700: "rgb(109 40 217 / <alpha-value>)",   // #6D28D9  darker
          800: "rgb(91 33 182 / <alpha-value>)",    // #5B21B6
        },
        // ── Surface ───────────────────────────────────────────────────────
        surface: {
          page:    "rgb(248 248 252 / <alpha-value>)",  // #F8F8FC  main bg
          sidebar: "rgb(244 244 247 / <alpha-value>)",  // #F4F4F7  sidebar
          card:    "rgb(255 255 255 / <alpha-value>)",  // #FFFFFF
          hover:   "rgb(243 232 255 / <alpha-value>)",  // #F3E8FF  purple hover
          green:   "rgb(236 253 245 / <alpha-value>)",  // #ECFDF5  soft green bg
        },
        // ── Ink ───────────────────────────────────────────────────────────
        ink: {
          900:    "rgb(24 24 27 / <alpha-value>)",   // #18181B  primary text
          600:    "rgb(113 113 122 / <alpha-value>)", // #71717A  secondary
          400:    "rgb(161 161 170 / <alpha-value>)", // #A1A1AA  placeholder
          border: "rgb(228 228 231 / <alpha-value>)", // #E4E4E7  borders
        },
        // ── State ─────────────────────────────────────────────────────────
        success: "rgb(16 185 129 / <alpha-value>)",  // #10B981
        danger:  "rgb(239 68 68  / <alpha-value>)",  // #EF4444
        warning: "rgb(245 158 11 / <alpha-value>)",  // #F59E0B
      },
      fontFamily: {
        sans: ["Inter", "'Plus Jakarta Sans'", "system-ui", "sans-serif"],
      },
      borderRadius: {
        "2xl": "16px",
        "3xl": "24px",
        "4xl": "32px",
      },
      animation: {
        "fade-in":    "fadeIn 0.2s ease",
        "slide-up":   "slideUp 0.3s cubic-bezier(0.16,1,0.3,1)",
        "scale-in":   "scaleIn 0.25s cubic-bezier(0.16,1,0.3,1)",
        "modal-in":   "modalIn 0.25s cubic-bezier(0.16,1,0.3,1)",
        "shimmer":    "shimmer 1.8s linear infinite",
        "spin":       "spin 0.8s linear infinite",
      },
      keyframes: {
        fadeIn:  { "0%": { opacity: 0 },              "100%": { opacity: 1 } },
        slideUp: { "0%": { opacity: 0, transform: "translateY(12px)" }, "100%": { opacity: 1, transform: "translateY(0)" } },
        scaleIn: { "0%": { opacity: 0, transform: "scale(0.96)" },     "100%": { opacity: 1, transform: "scale(1)" } },
        modalIn: { "0%": { opacity: 0, transform: "scale(0.94) translateY(8px)" }, "100%": { opacity: 1, transform: "scale(1) translateY(0)" } },
        shimmer: { "0%": { backgroundPosition: "-200% 0" }, "100%": { backgroundPosition: "200% 0" } },
      },
      boxShadow: {
        "xs":      "0 1px 2px rgb(0 0 0 / 0.05)",
        "sm":      "0 1px 3px rgb(0 0 0 / 0.08), 0 1px 2px rgb(0 0 0 / 0.04)",
        "md":      "0 4px 12px rgb(0 0 0 / 0.08), 0 2px 4px rgb(0 0 0 / 0.04)",
        "lg":      "0 8px 24px rgb(0 0 0 / 0.10), 0 3px 6px rgb(0 0 0 / 0.04)",
        "xl":      "0 16px 48px rgb(0 0 0 / 0.12), 0 4px 12px rgb(0 0 0 / 0.06)",
        "purple":  "0 4px 14px rgb(139 92 246 / 0.30)",
        "purple-lg":"0 8px 24px rgb(139 92 246 / 0.35)",
        "focus":   "0 0 0 3px rgb(139 92 246 / 0.25)",
      },
    },
  },
  plugins: [],
};

import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { LayoutDashboard, User, FileText, LogOut, Sparkles } from "lucide-react";
import { useAuth } from "../context/AuthContext";

const navItems = [
  { to: "/dashboard", label: "Dashboard",     icon: LayoutDashboard },
  { to: "/profile",   label: "My Profile",    icon: User },
  { to: "/resume",    label: "Resume Upload", icon: FileText },
];

export default function Sidebar() {
  const { logout, user } = useAuth();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    navigate("/login");
  }

  const initials = user?.name
    ? user.name.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase()
    : "?";

  return (
    <aside className="fixed inset-y-0 left-0 w-64 flex flex-col z-40 bg-white border-r border-ink-border shadow-sidebar">

      {/* Brand */}
      <div className="flex items-center gap-3 px-6 py-5 border-b border-ink-border">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-brand-blue to-brand-teal flex items-center justify-center shadow-sm flex-shrink-0">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <div className="leading-none">
          <div className="text-[17px] font-extrabold tracking-tight">
            <span className="text-ink-primary">Career</span>
            <span className="text-gradient-blue">Cast</span>
          </div>
          <p className="text-[10px] text-ink-secondary mt-0.5 tracking-wider uppercase">AI Career Platform</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {navItems.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `group flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 ${
                isActive
                  ? "bg-surface-hover text-brand-blue border border-brand-blue/20"
                  : "text-ink-secondary hover:text-ink-primary hover:bg-surface-hover border border-transparent"
              }`
            }
          >
            {({ isActive }) => (
              <>
                {/* Active left bar */}
                {isActive && (
                  <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 rounded-r-full bg-brand-blue" />
                )}
                <Icon
                  className={`w-4.5 h-4.5 flex-shrink-0 ${
                    isActive ? "text-brand-blue" : "text-ink-secondary group-hover:text-ink-primary"
                  }`}
                  style={{ width: "18px", height: "18px" }}
                />
                <span>{label}</span>
                {isActive && (
                  <span className="ml-auto w-1.5 h-1.5 rounded-full bg-brand-blue opacity-70" />
                )}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Divider */}
      <div className="h-px mx-4 bg-ink-border" />

      {/* User strip + logout */}
      <div className="px-3 py-4 space-y-1">
        <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl bg-surface-hover border border-ink-border mb-1">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-blue to-brand-teal flex items-center justify-center flex-shrink-0 text-xs font-bold text-white shadow-sm">
            {initials}
          </div>
          <div className="min-w-0">
            <p className="text-ink-primary text-xs font-semibold truncate">{user?.name}</p>
            <p className="text-ink-secondary text-[10px] truncate">{user?.email}</p>
          </div>
        </div>

        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium text-ink-secondary hover:text-red-600 hover:bg-red-50 border border-transparent hover:border-red-100 transition-all duration-150 group"
        >
          <LogOut className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" style={{ width: "16px", height: "16px" }} />
          Sign out
        </button>
      </div>
    </aside>
  );
}

import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff, AlertCircle, ArrowRight, Sparkles, Check } from "lucide-react";
import { useAuth } from "../context/AuthContext";

function PageBg() {
  return (
    <div className="fixed inset-0 pointer-events-none z-0" aria-hidden="true">
      <div className="absolute inset-0 bg-gradient-to-br from-surface-teal via-surface-bg to-surface-hover" />
      <div
        className="absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage: "radial-gradient(circle, #CBD5E1 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />
    </div>
  );
}

function InputField({ label, name, type, value, onChange, placeholder, error, suffix }) {
  return (
    <div>
      <label className="block text-sm font-medium text-ink-primary mb-1.5">{label}</label>
      <div className="relative">
        <input
          type={type || "text"}
          name={name}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          autoComplete={
            name === "password" ? "new-password"
            : name === "confirm_password" ? "new-password"
            : name
          }
          className={`
            w-full bg-white border rounded-xl px-4 py-3 text-ink-primary text-sm
            placeholder-ink-secondary/50 outline-none transition-all duration-150
            ${error
              ? "border-state-error focus:border-state-error focus:ring-2 focus:ring-state-error/20"
              : "border-ink-border focus:border-brand-teal focus:ring-2 focus:ring-brand-teal/15 hover:border-brand-teal/40"
            }
            ${suffix ? "pr-11" : ""}
          `}
        />
        {suffix && (
          <div className="absolute right-3 top-1/2 -translate-y-1/2">{suffix}</div>
        )}
      </div>
      {error && (
        <p className="flex items-center gap-1.5 text-state-error text-xs mt-1.5 animate-fade-in">
          <AlertCircle style={{ width: "12px", height: "12px", flexShrink: 0 }} /> {error}
        </p>
      )}
    </div>
  );
}

/* Password strength meter */
function PasswordStrength({ password }) {
  const checks = [
    { label: "6+ characters", ok: password.length >= 6 },
    { label: "Has a number",  ok: /\d/.test(password) },
    { label: "Has a letter",  ok: /[a-zA-Z]/.test(password) },
  ];
  const score   = checks.filter((c) => c.ok).length;
  const barColors = ["bg-red-400", "bg-yellow-400", "bg-state-success"];
  const labels  = ["Weak", "Fair", "Strong"];
  if (!password) return null;
  return (
    <div className="mt-2 animate-fade-in">
      <div className="flex gap-1 mb-1.5">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className={`h-1 flex-1 rounded-full transition-all duration-300 ${
              i < score ? barColors[score - 1] : "bg-ink-border"
            }`}
          />
        ))}
      </div>
      <div className="flex items-center gap-4">
        {checks.map((c) => (
          <span key={c.label} className={`text-xs flex items-center gap-1 ${c.ok ? "text-state-success" : "text-ink-secondary"}`}>
            <Check style={{ width: "11px", height: "11px", opacity: c.ok ? 1 : 0.3 }} />
            {c.label}
          </span>
        ))}
      </div>
    </div>
  );
}

export default function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();

  const [form, setForm]   = useState({ name: "", email: "", password: "", confirm_password: "" });
  const [show, setShow]   = useState({ password: false, confirm: false });
  const [errors, setErrors] = useState({});
  const [apiError, setApiError] = useState("");
  const [loading, setLoading]   = useState(false);

  function validate() {
    const e = {};
    if (!form.name.trim()) e.name = "Full name is required.";
    if (!form.email.trim()) e.email = "Email is required.";
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = "Enter a valid email address.";
    if (!form.password) e.password = "Password is required.";
    else if (form.password.length < 6) e.password = "Password must be at least 6 characters.";
    if (!form.confirm_password) e.confirm_password = "Please confirm your password.";
    else if (form.password !== form.confirm_password) e.confirm_password = "Passwords do not match.";
    return e;
  }

  async function handleSubmit(ev) {
    ev.preventDefault();
    setApiError("");
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    setErrors({});
    setLoading(true);
    try {
      await register(form.name, form.email, form.password, form.confirm_password);
      navigate("/dashboard");
    } catch (err) {
      setApiError(err.response?.data?.detail || "Registration failed. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  function onChange(e) {
    setForm((p) => ({ ...p, [e.target.name]: e.target.value }));
    setErrors((p) => ({ ...p, [e.target.name]: "" }));
  }

  const eyeBtn = (field) => (
    <button
      type="button"
      onClick={() => setShow((p) => ({ ...p, [field]: !p[field] }))}
      className="text-ink-secondary hover:text-brand-teal transition-colors"
    >
      {show[field]
        ? <EyeOff style={{ width: "18px", height: "18px" }} />
        : <Eye   style={{ width: "18px", height: "18px" }} />
      }
    </button>
  );

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-10 relative">
      <PageBg />

      <div className="relative z-10 w-full max-w-md animate-scale-in">

        {/* Logo */}
        <div className="flex flex-col items-center mb-7">
          <div className="w-13 h-13 rounded-2xl bg-gradient-to-br from-brand-teal to-brand-blue flex items-center justify-center shadow-card-md mb-3"
            style={{ width: "52px", height: "52px" }}>
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight">
            <span className="text-ink-primary">Career</span>
            <span className="text-gradient-teal">Cast</span>
          </h1>
          <p className="text-ink-secondary text-sm mt-1">Join thousands building their career paths</p>
        </div>

        <div className="card-md rounded-2xl p-8">
          {/* Top accent — teal direction for register */}
          <div className="h-0.5 w-full rounded-full bg-gradient-to-r from-brand-teal via-brand-blue to-brand-teal mb-7" />

          <h2 className="text-xl font-bold text-ink-primary mb-1">Create account</h2>
          <p className="text-ink-secondary text-sm mb-5">Start your AI-powered career journey.</p>

          {apiError && (
            <div className="flex items-center gap-2.5 bg-red-50 border border-red-200 rounded-xl px-4 py-3 mb-5 animate-fade-in">
              <AlertCircle style={{ width: "16px", height: "16px", color: "#DC2626", flexShrink: 0 }} />
              <p className="text-red-700 text-sm">{apiError}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate className="space-y-4">
            <InputField label="Full Name"       name="name"             value={form.name}             onChange={onChange} placeholder="Jane Doe"              error={errors.name} />
            <InputField label="Email address"   name="email"  type="email" value={form.email}          onChange={onChange} placeholder="you@example.com"       error={errors.email} />
            <div>
              <InputField
                label="Password" name="password"
                type={show.password ? "text" : "password"}
                value={form.password} onChange={onChange}
                placeholder="Min. 6 characters" error={errors.password}
                suffix={eyeBtn("password")}
              />
              <PasswordStrength password={form.password} />
            </div>
            <InputField
              label="Confirm Password" name="confirm_password"
              type={show.confirm ? "text" : "password"}
              value={form.confirm_password} onChange={onChange}
              placeholder="Repeat your password" error={errors.confirm_password}
              suffix={eyeBtn("confirm")}
            />

            <button
              type="submit"
              disabled={loading}
              className="
                w-full flex items-center justify-center gap-2
                bg-brand-teal hover:bg-brand-teal-dark
                disabled:opacity-60 disabled:cursor-not-allowed
                text-white font-semibold text-sm py-3 rounded-xl
                shadow-sm hover:shadow-md transition-all duration-150 mt-1
              "
            >
              {loading ? (
                <>
                  <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Creating account…
                </>
              ) : (
                <>Create Account <ArrowRight style={{ width: "16px", height: "16px" }} /></>
              )}
            </button>
          </form>

          <div className="flex items-center gap-3 my-5">
            <div className="flex-1 h-px bg-ink-border" />
            <span className="text-ink-secondary text-xs">or</span>
            <div className="flex-1 h-px bg-ink-border" />
          </div>

          <p className="text-center text-ink-secondary text-sm">
            Already have an account?{" "}
            <Link to="/login" className="text-brand-teal hover:text-brand-teal-dark font-semibold underline underline-offset-2 transition-colors">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

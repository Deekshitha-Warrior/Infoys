import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff, AlertCircle, ArrowRight, Sparkles } from "lucide-react";
import { useAuth } from "../context/AuthContext";

/* ── Light background decoration ──────────────────────────────────────── */
function PageBg() {
  return (
    <div className="fixed inset-0 pointer-events-none z-0" aria-hidden="true">
      {/* Soft blue-teal gradient top strip */}
      <div className="absolute inset-0 bg-gradient-to-br from-surface-hover via-surface-bg to-surface-teal" />
      {/* Very faint dot grid */}
      <div
        className="absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage: "radial-gradient(circle, #CBD5E1 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />
    </div>
  );
}

/* ── Input field ───────────────────────────────────────────────────────── */
function InputField({ label, name, type = "text", value, onChange, placeholder, error, suffix }) {
  return (
    <div>
      <label className="block text-sm font-medium text-ink-primary mb-1.5">{label}</label>
      <div className="relative">
        <input
          type={type}
          name={name}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          autoComplete={name === "password" ? "current-password" : name}
          className={`
            w-full bg-white border rounded-xl px-4 py-3 text-ink-primary text-sm
            placeholder-ink-secondary/50 outline-none transition-all duration-150
            ${error
              ? "border-state-error focus:border-state-error focus:ring-2 focus:ring-state-error/20"
              : "border-ink-border focus:border-brand-blue focus:ring-2 focus:ring-brand-blue/15 hover:border-brand-blue/40"
            }
            ${suffix ? "pr-11" : ""}
          `}
        />
        {suffix && (
          <div className="absolute right-3 top-1/2 -translate-y-1/2">{suffix}</div>
        )}
      </div>
      {error && (
        <p className="flex items-center gap-1.5 text-state-error text-xs mt-1.5 animate-fade-in">
          <AlertCircle style={{ width: "12px", height: "12px", flexShrink: 0 }} /> {error}
        </p>
      )}
    </div>
  );
}

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();

  const [form, setForm]       = useState({ email: "", password: "" });
  const [showPwd, setShowPwd] = useState(false);
  const [errors, setErrors]   = useState({});
  const [apiError, setApiError] = useState("");
  const [loading, setLoading]   = useState(false);

  function validate() {
    const e = {};
    if (!form.email.trim()) e.email = "Email is required.";
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = "Enter a valid email address.";
    if (!form.password) e.password = "Password is required.";
    return e;
  }

  async function handleSubmit(ev) {
    ev.preventDefault();
    setApiError("");
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    setErrors({});
    setLoading(true);
    try {
      await login(form.email, form.password);
      navigate("/dashboard");
    } catch (err) {
      setApiError(err.response?.data?.detail || "Invalid email or password.");
    } finally {
      setLoading(false);
    }
  }

  function onChange(e) {
    setForm((p) => ({ ...p, [e.target.name]: e.target.value }));
    setErrors((p) => ({ ...p, [e.target.name]: "" }));
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 relative">
      <PageBg />

      <div className="relative z-10 w-full max-w-md animate-scale-in">

        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-brand-blue to-brand-teal flex items-center justify-center shadow-card-md mb-4">
            <Sparkles className="w-7 h-7 text-white" />
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight">
            <span className="text-ink-primary">Career</span>
            <span className="text-gradient-blue">Cast</span>
          </h1>
          <p className="text-ink-secondary text-sm mt-1">AI-Powered Career Intelligence</p>
        </div>

        {/* Card */}
        <div className="card-md rounded-2xl p-8">
          {/* Top accent line */}
          <div className="h-0.5 w-full rounded-full bg-gradient-to-r from-brand-blue via-brand-teal to-brand-blue mb-7" />

          <h2 className="text-xl font-bold text-ink-primary mb-1">Welcome back</h2>
          <p className="text-ink-secondary text-sm mb-6">Sign in to continue to your dashboard.</p>

          {/* API error */}
          {apiError && (
            <div className="flex items-center gap-2.5 bg-red-50 border border-red-200 rounded-xl px-4 py-3 mb-5 animate-fade-in">
              <AlertCircle style={{ width: "16px", height: "16px", color: "#DC2626", flexShrink: 0 }} />
              <p className="text-red-700 text-sm">{apiError}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate className="space-y-4">
            <InputField
              label="Email address"
              name="email"
              type="email"
              value={form.email}
              onChange={onChange}
              placeholder="you@example.com"
              error={errors.email}
            />

            <InputField
              label="Password"
              name="password"
              type={showPwd ? "text" : "password"}
              value={form.password}
              onChange={onChange}
              placeholder="••••••••"
              error={errors.password}
              suffix={
                <button
                  type="button"
                  onClick={() => setShowPwd((p) => !p)}
                  className="text-ink-secondary hover:text-brand-blue transition-colors"
                  aria-label={showPwd ? "Hide password" : "Show password"}
                >
                  {showPwd
                    ? <EyeOff style={{ width: "18px", height: "18px" }} />
                    : <Eye style={{ width: "18px", height: "18px" }} />
                  }
                </button>
              }
            />

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="
                w-full flex items-center justify-center gap-2
                bg-brand-blue hover:bg-brand-blue-dark
                disabled:opacity-60 disabled:cursor-not-allowed
                text-white font-semibold text-sm py-3 rounded-xl
                shadow-sm hover:shadow-md transition-all duration-150 mt-1
              "
            >
              {loading ? (
                <>
                  <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Signing in…
                </>
              ) : (
                <>Sign In <ArrowRight style={{ width: "16px", height: "16px" }} /></>
              )}
            </button>
          </form>

          {/* Teal accent separator */}
          <div className="flex items-center gap-3 my-5">
            <div className="flex-1 h-px bg-ink-border" />
            <span className="text-ink-secondary text-xs">or</span>
            <div className="flex-1 h-px bg-ink-border" />
          </div>

          <p className="text-center text-ink-secondary text-sm">
            Don't have an account?{" "}
            <Link to="/register" className="text-brand-blue hover:text-brand-blue-dark font-semibold underline underline-offset-2 transition-colors">
              Create account
            </Link>
          </p>
        </div>

        <p className="text-center text-ink-secondary/60 text-xs mt-6">
          Secure · AI-Powered · Free to use
        </p>
      </div>
    </div>
  );
}

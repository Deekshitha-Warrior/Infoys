import React from "react";
import { Bell } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function TopNav({ title }) {
  const { user } = useAuth();

  const initials = user?.name
    ? user.name.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase()
    : "?";

  return (
    <header className="h-16 bg-white border-b border-ink-border shadow-card flex items-center justify-between px-8 sticky top-0 z-30">

      {/* Left: page title with blue accent bar */}
      <div className="flex items-center gap-3">
        <div className="w-1 h-5 rounded-full bg-gradient-to-b from-brand-blue to-brand-teal" />
        <h1 className="text-base font-semibold text-ink-primary tracking-tight">{title}</h1>
      </div>

      {/* Right: notification + user pill */}
      <div className="flex items-center gap-2.5">
        {/* Bell */}
        <button
          className="relative w-9 h-9 rounded-xl bg-surface-bg hover:bg-surface-hover border border-ink-border flex items-center justify-center text-ink-secondary hover:text-brand-blue transition-all"
          aria-label="Notifications"
        >
          <Bell style={{ width: "16px", height: "16px" }} />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-brand-teal rounded-full" />
        </button>

        {/* User pill */}
        <div className="flex items-center gap-2.5 pl-3 pr-2 py-1.5 rounded-xl bg-surface-bg hover:bg-surface-hover border border-ink-border transition-all cursor-default">
          <span className="text-sm text-ink-secondary hidden sm:block">
            Hi, <span className="text-ink-primary font-semibold">{user?.name?.split(" ")[0]}</span>
          </span>
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-brand-blue to-brand-teal flex items-center justify-center text-xs font-bold text-white shadow-sm flex-shrink-0">
            {initials}
          </div>
        </div>
      </div>
    </header>
  );
}
